<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Attributes\Fillable;

#[Fillable(['role_name'])]
class Role extends Model
{
    use HasFactory;

    protected $primaryKey = 'role_id'; 
}